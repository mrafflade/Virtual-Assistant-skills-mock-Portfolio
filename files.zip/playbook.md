# Inbox & Calendar Playbook

*A working agreement between a founder and their Virtual Assistant. This is a sample written for a fictional founder (Ama Owusu, GreenCart). In a real role I would agree each point with the founder in the first 30-minute call.*

---

## 1. What I handle, what I ask about, what I never do

| I handle on my own | I ask first | I never do |
|---|---|---|
| Scheduling and rescheduling routine meetings | Accepting or declining anything with investors, press, or new partners | Share passwords, banking details, or confidential documents |
| Sending prepared replies (templates) | Replying to anything that commits money, time, or a decision | Reply on the founder's behalf in a tone or on a topic I'm unsure about |
| Archiving newsletters, receipts, and notifications | Moving or cancelling a meeting with a VIP | Delete anything without a recovery option |
| Chasing replies with polite follow-ups | Sharing the founder's private contact details | Agree to anything "in principle" for the founder |
| Booking travel within agreed limits | Spending above the agreed limit | Make public posts without approval |

**Rule of thumb:** if I'm less than 90% sure the founder would say yes, I ask.

---

## 2. Inbox system

### Four piles
Every email goes into one of four piles:

1. **Reply today:** urgent and time-sensitive. I draft a reply and flag it.
2. **Needs the founder's decision:** I summarise it in two lines and list the options.
3. **I can handle it:** scheduling, admin, routine questions. I just do it.
4. **Archive / unsubscribe:** no action needed.

### Labels
| Label | Meaning |
|---|---|
| `1-Urgent` | Needs a reply or decision today |
| `2-Decision` | Waiting on the founder |
| `3-Waiting` | Waiting on someone else (also logged in the follow-up tracker) |
| `4-VIP` | Investors, key clients, partners, advisors |
| `5-Finance` | Invoices, receipts, payments |
| `6-Reference` | Keep for later |

### Check times
Three inbox passes a day instead of constant checking:
- **Morning:** triage overnight email, prepare the morning brief
- **Midday:** handle new urgent items, send follow-ups
- **End of day:** clear what I can, send the wrap-up

### Response targets
| Type | Target |
|---|---|
| VIP or urgent | Flag to the founder within 1 hour; reply within 4 hours |
| Routine business | Within 1 working day |
| Low priority | Within 2 working days |

### Flag to the founder immediately
Anything involving legal threats, payment problems, a complaint from a key client, press enquiries, or a time-sensitive investor request.

---

## 3. Calendar rules

- **Every meeting needs:** a clear title, a time zone, a video link or location, and a one-line purpose. Where possible, an agenda and prep notes.
- **Buffers:** 15 minutes between meetings; 30 minutes after long or high-stakes ones.
- **Focus blocks:** two protected 90-minute blocks per week for deep work. These are not moved without the founder's say-so.
- **No-meeting time:** one half-day per week with no meetings where possible.
- **Time zones:** every invite shows the time in the other person's time zone as well as Accra time (GMT).
- **Scheduling link:** used for routine meetings so there is no back-and-forth. VIPs get personal offers of 2 to 3 times.
- **Double bookings:** I fix the conflict the same day and tell the founder what moved and why.
- **Declining:** I can politely decline meetings that have no agenda, no clear outcome, or overlap with focus time, using the approved template.
- **Reminders:** a prep note goes out the evening before every important meeting.

---

## 4. Follow-up rules

1. Every promise made in an email or meeting goes in the **follow-up tracker** the same day.
2. First nudge: 2 working days after the original message.
3. Second nudge: 3 working days after the first.
4. After the third attempt with no reply, I flag it to the founder for a decision.
5. After every meeting, I send the founder the action items within 2 hours.

---

## 5. Daily and weekly rhythm

**Daily**
- Morning: triage inbox, check calendar for conflicts, send the **morning brief**
- Midday: follow-ups, scheduling, drafts for approval
- End of day: short wrap-up (done / waiting on you / tomorrow)

**Weekly**
- Friday: review the tracker, close completed items, and plan the next week's calendar
- Monthly: review this playbook with the founder and update rules that no longer fit

---

## 6. Confidentiality
I treat everything I see as confidential. I use shared password managers rather than sending passwords, keep documents in shared folders with the right permissions, and never discuss the founder's business outside the work.
