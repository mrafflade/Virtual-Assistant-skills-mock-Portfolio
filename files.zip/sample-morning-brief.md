# Morning Brief: Tuesday, 17 November 2026

*Sample daily note for a fictional founder (Ama Owusu, GreenCart). In practice this lands in the founder's inbox or chat by 7:30 AM and takes under two minutes to read.*

---

**Good morning Ama. Here's your day.**

## Your top 3 priorities today
1. **Send the revised pitch deck to Kojo Asante (Seed Fund).** Overdue since Friday. The deck is ready for your final look and I have drafted the cover email.
2. **Sign off the contract draft for Boateng & Co.** Due tomorrow. I have highlighted the two clauses that changed.
3. **Confirm the offsite venue.** The venue needs an answer by 5 PM today.

## Today's meetings (Accra time, GMT)
| Time | Meeting | Notes |
|---|---|---|
| 09:30 – 10:00 | Team stand-up | Video link in the invite. No prep needed. |
| 11:00 – 11:45 | Call with Efua Mensah (FreshFarm Ltd) | Topic: delivery schedule. I've attached her last email and the current schedule. |
| 12:00 – 14:00 | **Focus block (protected)** | Pitch deck and contract review |
| 15:00 – 15:30 | Interview: ops manager candidate | CV and 3 suggested questions attached |

*Buffer time of 15 minutes has been added between each meeting.*

## Decisions waiting on you
| Decision | Options | My suggestion |
|---|---|---|
| Venue for team offsite | A) Lakeside hall: GHS 4,500; B) City hotel: GHS 6,000 | A, same capacity, lower cost |
| Delta Retail invoice #1042 (overdue) | A) Send a firm reminder today; B) Call them yourself | A, and I'll flag if no reply by Thursday |

## Emails drafted for your approval
- Reply to Kojo Asante: pitch deck cover note
- Reply to Efua Mensah: confirming tomorrow's call
- Polite chase to Delta Retail: invoice #1042

*Reply "send" to any of these and I'll send them straight away.*

## Follow-ups due
| Item | Who | Status |
|---|---|---|
| Intro email: founder to Nana Adjei | Me, drafting | Due 26 Nov |
| Invoice #1042 | Delta Retail | **Overdue (3 days)** |
| Meeting notes to Dr. Frimpong | You | Due tomorrow |

## Heads-up
- Thursday 19 November has three back-to-back meetings. I've proposed moving the 4 PM catch-up to Friday. Let me know if that's okay.
- Your flight to Kumasi is not booked yet. I need your preferred travel date by Wednesday.

---

**Evening wrap-up:** I'll send a short note at 5:30 PM with what was done, what's still waiting on you, and tomorrow's plan.
