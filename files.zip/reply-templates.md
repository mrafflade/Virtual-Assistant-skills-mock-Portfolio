# Reply Template Pack

*Ready-to-send emails a Virtual Assistant uses on behalf of a founder. Written for a fictional founder (Ama Owusu, GreenCart). Words in [brackets] are filled in each time. Every template is short, polite, and has one clear next step.*

**How I use these:** templates cover the routine 80% so the founder only reads what needs their brain. I always check names, dates, and tone before sending, and anything sensitive goes to the founder first.

---

## 1. Offering meeting times

**Subject:** Meeting with Ama Owusu: times to choose from

Hi [Name],

Thank you for reaching out. I'm Kelvin, assisting Ama with her calendar. She'd be happy to meet.

Here are three times that work (all [time zone]):
- [Day, date, time]
- [Day, date, time]
- [Day, date, time]

Please let me know which suits you best and I'll send the invite with the video link. If none work, send me a few that do and I'll find a match.

Kind regards,
Kelvin
Assistant to Ama Owusu

---

## 2. Confirming a meeting

**Subject:** Confirmed: [Meeting title], [date] at [time]

Hi [Name],

This is confirmed for [day, date] at [time] [time zone]. The invite and [video link / location] are attached.

[One line on purpose or agenda.] Please tell me if there's anything you'd like Ama to look at beforehand.

Kind regards,
Kelvin

---

## 3. Rescheduling

**Subject:** Rescheduling: [Meeting title]

Hi [Name],

I'm sorry for the change. Ama has had a scheduling conflict and needs to move our meeting on [original date].

Could we try one of these instead?
- [Option 1]
- [Option 2]

Thank you for your flexibility, and apologies again for the inconvenience.

Kind regards,
Kelvin

---

## 4. Introducing two people (after the founder has approved)

**Subject:** Introduction: [Name A] <> [Name B]

Hi [Name A] and [Name B],

Ama asked me to connect you both.

**[Name A]** is [one-line role and why they matter]. **[Name B]** is [one-line role]. Ama thought you'd benefit from speaking because [specific reason].

I'll let you take it from here. Thank you both.

Kind regards,
Kelvin on behalf of Ama

---

## 5. Politely declining a meeting

**Subject:** Re: [Their subject]

Hi [Name],

Thank you for thinking of Ama. She's keeping her calendar focused on a few priorities right now, so she won't be able to take this meeting.

[Optional: If it's helpful, you're welcome to send a short summary by email and I'll make sure she sees it.]

Wishing you all the best with [project or goal].

Kind regards,
Kelvin

---

## 6. Holding reply (when the founder needs time)

**Subject:** Re: [Their subject]

Hi [Name],

Thank you for your message. Ama has received it and wants to give it proper attention. She'll get back to you by [day/date].

If anything is time-sensitive in the meantime, please let me know.

Kind regards,
Kelvin

---

## 7. First follow-up (gentle nudge)

**Subject:** Re: [Original subject]

Hi [Name],

I hope your week is going well. I'm following up on my email of [date] about [topic]. Do you have an update?

If it would help, I'm happy to [offer: resend the document / set up a quick call].

Thank you,
Kelvin

---

## 8. Second follow-up

**Subject:** Re: [Original subject]

Hi [Name],

Just a quick follow-up on [topic]. We'd like to finalise [outcome] by [date], so a reply by [day] would be very helpful.

If something has changed on your side, a quick note is fine and we'll adjust.

Thank you,
Kelvin

---

## 9. Final follow-up

**Subject:** Closing the loop: [topic]

Hi [Name],

I've reached out a few times about [topic] and haven't heard back, so I'll assume the timing isn't right. Ama is happy to pick this up again whenever it suits you. Just reply to this email.

All the best,
Kelvin

---

## 10. Chasing an overdue invoice

**Subject:** Reminder: invoice #[number], due [date]

Hi [Name],

I hope you're well. This is a friendly reminder that invoice #[number] for [amount] was due on [date] and our records show it as unpaid.

The invoice is attached. Could you confirm the expected payment date? If it has been paid already, please send the payment reference so we can match it.

Thank you,
Kelvin
On behalf of Ama Owusu, GreenCart

---

## 11. Thank-you after a meeting

**Subject:** Thank you: [Meeting title]

Hi [Name],

Thank you for your time today. Ama enjoyed the conversation.

As agreed, the next steps are:
- [Action, owner, date]
- [Action, owner, date]

Please let me know if I've missed anything.

Kind regards,
Kelvin
