# Virtual Assistant Portfolio: Kelvin Sedem Dzisah

Hi, I'm Kelvin, an Information Technology graduate based in Accra, Ghana. This portfolio shows how I would take control of a busy founder's inbox, calendar, and follow-ups.

Everything here is a **working sample built for a fictional founder** (Ama Owusu, GreenCart). All names, companies, and numbers are made up, so no real or confidential information is shown.

---

## The projects

### 1. [Follow-Up Tracker](01-follow-up-tracker/follow-up-tracker.xlsx)
A spreadsheet that makes sure no promise slips. Each item has a contact, category, due date, priority, and status. Overdue and due-today items are flagged automatically, and a summary page shows what needs attention right now.

*Shows:* organisation, attention to detail, and building simple systems that work without extra effort.

### 2. [Inbox & Calendar Playbook](02-inbox-calendar-playbook/playbook.md)
The rulebook I would agree with a founder in week one: what I handle alone, what I ask about first, how email is sorted, how meetings are protected, and how follow-ups are chased.

*Shows:* judgement, clear communication, and respect for confidentiality.

### 3. [Sample Morning Brief](03-sample-morning-brief/sample-morning-brief.md)
The two-minute daily note a founder would get from me: top priorities, meetings, decisions waiting, drafts to approve, and follow-ups due.

*Shows:* how I keep a founder informed without adding to their workload.

### 4. [Reply Template Pack](04-reply-templates/reply-templates.md)
Eleven ready-to-send emails for scheduling, introductions, declining politely, follow-ups, invoice reminders, and thank-yous.

*Shows:* professional writing and speed on routine communication.

---

## How these fit together

```
Email arrives → sorted with the playbook → templates handle the routine replies
      ↓
Promises and open loops → logged in the tracker
      ↓
Every morning → morning brief summarises what matters today
```

---

## More of my work

- **MediConnect:** my final-year project at the Ghana Communication Technology University (GCTU), a web platform for real-time patient-doctor chat and video calling. [add link to repo, demo, or report]
- **Finance internship:** Ghana Ports and Harbours Authority, Tema (February to April 2025).

## About me
- BSc. Information Technology, GCTU (2023 to 2026)
- Tools I use: [list the ones you genuinely know, e.g. Google Workspace, Excel, Notion]
- Based in Accra (GMT). Availability: [your hours]

## Contact
- Email: [your email]
- LinkedIn: [your LinkedIn link]
